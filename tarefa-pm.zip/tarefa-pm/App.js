import React from 'react';
import { SafeAreaView, View, FlatList, StyleSheet, Text, StatusBar } from 'react-native';

const DATA = [
  {
    nome: 'Yuri',
  },
  {
    nome: 'Yago',
  },
  {
    nome: 'Gisele',
  },
  {
    nome: 'Cida',
  },
  {
    nome: 'Teresa',
  },
  {
    nome: 'Alcides',
  },
];

const Item = ({ nome }) => (
  <View style={styles.item}>
    <Text style={styles.nome}>{nome}</Text>
  </View>
);

const App = () => {
  const renderItem = ({ item }) => (
    <Item nome={item.nome} />
  );

  return (
    <View style={styles.container}>
      <FlatList
        data={DATA}
        renderItem={renderItem}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  item: {
    backgroundColor: '#00BFFF',
    padding: 20,
    marginVertical: 8,
    marginHorizontal: 16,
  },
  nome: {
    fontSize: 32,
  },
});

export default App;
